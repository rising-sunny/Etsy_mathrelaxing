Famous Equations — Wall Art Set of 6
MathRelaxing scientific plates

Six gallery prints in one download:
  1. Fourier Series — square-wave harmonics
  2. Wave Equation — standing modes on a string
  3. Dirac Equation — matter & antimatter continuum
  4. Navier–Stokes — flow past a cylinder
  5. Euler's Identity — complex unit circle
  6. Mandelbrot Set — geometry of chaos

Each design includes 2:3 (12×18) and A4 masters at 300 dpi.
Matte paper recommended. Personal use only.

© MathRelaxing
