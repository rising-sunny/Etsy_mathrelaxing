SPIRAL TILINGS - Wall Art Set of 6
MathRelaxing

Six prints of a spiral tiling: a single tile shape, repeated so that every
piece stays the same size while the whole plane winds around a centre.

Rings of constant thickness are cut into pieces whose count grows with the
radius, so the tiles never stretch. The zigzag on each ring boundary keeps a
constant pitch measured along the arc, which is what lets rings with different
piece counts still lock together. Those surplus pieces per ring are exactly
what curl the pattern into spiral arms, and the colour follows the same
modular count -- so what you see is the arithmetic, not a filter.

01 Vortex     teal and rust        02 Helix     indigo and amber
03 Radiant    terracotta and clay  04 Corona    forest and ochre
05 Drift      plum and gold        06 Pinwheel  monochrome

WHAT'S INCLUDED
  Each design at 9 x 11.5 in and 11 x 14 in, 300 dpi JPG.
  Both fit standard frames; print at home, at a copy shop or online.

This is a DIGITAL download - nothing is shipped.
(c) MathRelaxing. Personal use only. Not for redistribution or resale.
