MathRelaxing Editorial Resume Kit
================================

For engineers, scientists, analysts, and precision professionals.

INCLUDED
--------
templates/
  01_ATS_Resume_Template.docx              pure white, portal-safe
  01_ATS_Resume_SAMPLE.docx
  02_Editorial_Style_CreamVeil.docx        + SAMPLE
  02_Editorial_Style_ScientificGrid.docx   + SAMPLE
  02_Editorial_Style_GoldGeometry.docx     + SAMPLE
  02_Editorial_Style_PhiWhisper.docx       + SAMPLE
  02_Editorial_Style_NavyEdge.docx         + SAMPLE
  03_Cover_Letter_Template.docx / SAMPLE
  04_References_Template.docx / SAMPLE

backgrounds/
  bg_*.png          semi-transparent full-page art (swap freely)
  _styles_contact_sheet.jpg
  BACKGROUNDS_README.txt

samples/
  Sample_Editorial_Resume.pdf
  HOW_TO_USE.pdf

BACKGROUNDS
-----------
Editorial templates embed a faint MathRelaxing background BEHIND the text
(cream page wash + decorative layer). Five styles ship as separate .docx files
so you can pick elegance level without design skills.

To swap: Header → click image → Change Picture → choose another backgrounds/bg_*.png
Wrap should stay Behind Text.

TIP
---
ATS template = company portals (no watermark).
Editorial styles = email / networking / portfolio PDF.

© MathRelaxing — personal use only.
