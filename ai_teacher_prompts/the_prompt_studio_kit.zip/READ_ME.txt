The Prompt Studio — A Teacher's AI Toolkit

INCLUDED
  The_Prompt_Studio_84_Teacher_Prompts.pdf  — printable catalog of all 84 prompts
  Prompt_Studio_interactive_tool.html       — open in any browser; pick a prompt,
                                              fill the blanks, click Copy. Works offline.

HOW TO USE
  Replace every [bracket] with your details, then paste into ChatGPT, Claude or Gemini.
  You are the expert — always review and edit the AI's output before using it with students.

Original, curated teaching prompts. Personal / single-classroom use. Not for resale.
