STEM Study OS — iPad Stickers
================================

Transparent PNG stickers for digital notebooks.

INCLUDED
  PNG_individual/     all stickers flat
  PNG_by_module/      status, subjects, symbols, progress, notes, mood, tabs, utility
  Sheets/             printable contact sheet

APPS
  GoodNotes, Notability, Procreate, Freeform, Notes, Keynote…

HOW TO IMPORT (GoodNotes)
  1. Unzip the download
  2. Elements → + → Import images
  3. Select PNGs (or a whole module folder)

Personal use. Not for redistribution or resale.
