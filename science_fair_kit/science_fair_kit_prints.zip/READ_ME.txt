Science Fair Project Kit

INCLUDED
  Science_Fair_Project_Kit.pdf — 17 pages, US Letter, 300 dpi

PRINTING
  Print on white or light card. Headers look great on colored paper.
  Trim header cards along the rounded edge and mount on your tri-fold board.

Personal / single-classroom use. Not for redistribution or resale.
