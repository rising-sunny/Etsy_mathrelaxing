History of Calculus — Math Wall Art
MathRelaxing timeline poster

Nine milestones in the history of calculus, from Archimedes' method of
exhaustion to Robinson's nonstandard analysis — each paired with a bespoke
diagram and its defining equation. Dark, gold-linework editorial plate.

WHAT YOU GET
High-resolution JPG prints at 300 dpi, portrait / ISO-A ratio:
  • 12x17 in (signature size)
  • ISO A3
  • ISO A4

Print at home, a print shop, or online lab. Matte black frame recommended.
Frame not included. Personal use only.

© MathRelaxing
