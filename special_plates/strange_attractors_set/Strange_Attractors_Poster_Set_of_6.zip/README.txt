MathRelaxing Strange Attractors Set of 6
Lorenz, Rossler, Thomas, Four-Wing, Chen, Aizawa.
