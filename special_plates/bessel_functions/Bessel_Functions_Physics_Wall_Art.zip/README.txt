Bessel Functions — Physics Wall Art
MathRelaxing scientific plate

Scientific plate of Bessel functions J0, J1, J2 with zeros marked — cylindrical waves and circular drum modes. Cream graph paper, LaTeX, scipy.

WHAT YOU GET
High-resolution JPG prints at 300 dpi:
  • 2:3  (12×18 in)
  • 3:4  (12×16 in)
  • 4:5  (16×20 in)
  • 5:7  (10×14 in)
  • ISO A4 and A3

Print at home, a print shop, or online lab. Matte paper looks best.
Frame not included. Personal use only.

© MathRelaxing
