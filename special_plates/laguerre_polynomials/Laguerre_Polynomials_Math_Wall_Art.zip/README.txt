Laguerre Polynomials — Math Wall Art
MathRelaxing scientific plate

Scientific plate of Laguerre polynomials L0..L4 on [0,∞) — orthogonal basis for radial expansions and Gauss–Laguerre. LaTeX + scipy.

WHAT YOU GET
High-resolution JPG prints at 300 dpi:
  • 2:3  (12×18 in)
  • 3:4  (12×16 in)
  • 4:5  (16×20 in)
  • 5:7  (10×14 in)
  • ISO A4 and A3

Print at home, a print shop, or online lab. Matte paper looks best.
Frame not included. Personal use only.

© MathRelaxing
