MathRelaxing — Physics Formula Poster Set of 6
=============================================
Print-ready JPG files at 300 dpi (2×3 and A4 per design).
Personal use only. Not for redistribution.
https://www.etsy.com/shop/TheMathRelaxing
