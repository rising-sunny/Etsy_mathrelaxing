Airy Functions — Physics Wall Art
MathRelaxing scientific plate

Scientific plate of Airy Ai and Bi — oscillatory left, exponential right. Model equation for linear turning points / WKB. LaTeX + scipy.

WHAT YOU GET
High-resolution JPG prints at 300 dpi:
  • 2:3  (12×18 in)
  • 3:4  (12×16 in)
  • 4:5  (16×20 in)
  • 5:7  (10×14 in)
  • ISO A4 and A3

Print at home, a print shop, or online lab. Matte paper looks best.
Frame not included. Personal use only.

© MathRelaxing
