Turing Patterns: Reaction-Diffusion -- Set of 6
MathRelaxing scientific plate set

Six patterns straight out of the Gray-Scott reaction-diffusion model --
the same handful of pattern families (spots, holes, mazes, traveling
stripes, dense whorls, coalescing chaos) that show up on real leopards,
pufferfish, coral, tigers, fingertips, and cuttlefish skin. Each plate is
an actual numerical simulation of Alan Turing's morphogenesis equations,
colour-graded and printed full-bleed on a dark ground with gold linework.

WHAT YOU GET
Six designs, each as a high-resolution JPG at 300 dpi, portrait ratio:
  - 9 x 11.5 in (signature size)
  - 11 x 14 in

Print at home, a print shop, or online lab. Simple black frame
recommended -- these read best with breathing room around them.
Frame not included. Personal use only.

(c) MathRelaxing
