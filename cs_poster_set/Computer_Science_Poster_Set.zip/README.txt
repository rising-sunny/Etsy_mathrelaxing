Computer Science Educational Wall Art Set
MathRelaxing scientific plates

7 posters:
  1. How Algorithms Grow — Big-O complexity
  2. Ordered by Comparison — Binary search tree
  3. Sorted by Comparison — Bubble vs merge sort
  4. Boolean Building Blocks — Logic gates
  5. Seven Layers of the Network — OSI model
  6. LIFO & FIFO — Stack and queue
  7. States and Transitions — Finite state machine

Aspect ratios @ 240 dpi JPG:
  2:3 · 3:4 · 4:5 · 5:7 · ISO A4 · A3

Print on matte paper. Personal use only.
© MathRelaxing
