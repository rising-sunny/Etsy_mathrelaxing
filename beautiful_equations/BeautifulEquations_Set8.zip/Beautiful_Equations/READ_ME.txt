BEAUTIFUL EQUATIONS — The Set of 8
MathRelaxing · mathrelaxing.store

Thank you! This bundle contains 8 mathematical art prints, each set in
Computer Modern (the classic LaTeX typeface) on a deep navy ground.

WHAT'S INSIDE
-------------
PDF_vector_any_size/   8 vector PDFs. These print razor-sharp at ANY size —
                       from a small A5 card up to a huge gallery poster.
                       Best choice for most printers and print shops.
JPG_24x30in_300dpi/    8 JPG files, 7200 × 9000 px. Print-ready up to
                       24 × 30 inches at 300 dpi. Use these where a JPG is
                       required (Costco Photo, some online print services).

THE EQUATIONS
-------------
  Euler's Identity · The Pythagorean Theorem · Mass–Energy Equivalence
  The Golden Ratio · The Basel Problem · The Fundamental Theorem of Calculus
  The Normal Distribution · The Schrödinger Equation

PRINTING TIPS
-------------
· Proportion is 4:5 — frame in 8x10, 16x20 or 24x30 inch mounts.
· Best on matte or satin paper; stunning framed in a study, classroom,
  lab or office.
· Any local print shop or online service can handle these files.

© MathRelaxing. For personal use only. Not for redistribution or resale.
