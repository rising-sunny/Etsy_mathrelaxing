Unit Circle — Math Wall Art
MathRelaxing scientific plate

THE UNIT CIRCLE
Radians, degrees, and exact coordinates at special angles.
Key identities for trigonometry reference.

WHAT YOU GET
High-resolution JPG prints at 300 dpi, multiple aspect ratios:
  • 2:3  (12×18 in)
  • 3:4  (12×16 in)
  • 4:5  (16×20 in)
  • 5:7  (10×14 in)
  • ISO A4 and A3

Print at home, a print shop, or an online lab. Matte / textured paper looks best.
Frame not included. For personal use only.

© MathRelaxing
