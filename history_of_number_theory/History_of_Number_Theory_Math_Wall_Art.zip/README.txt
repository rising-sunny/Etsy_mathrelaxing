History of Number Theory — Math Wall Art
MathRelaxing timeline poster

Nine milestones in the history of number theory, from Euclid's proof that
there are infinitely many primes to Andrew Wiles' proof of Fermat's Last
Theorem — each paired with a bespoke diagram and its defining equation.
Dark, gold-linework editorial plate.

WHAT YOU GET
High-resolution JPG prints at 300 dpi, portrait / ISO-A ratio:
  • 12x17 in (signature size)
  • ISO A3
  • ISO A4

Print at home, a print shop, or online lab. Matte black frame recommended.
Frame not included. Personal use only.

© MathRelaxing
