The STEM Graph Paper Bundle — MathRelaxing
==========================================

8 grid styles, in US Letter (8.5x11 in) and A4:
  Square 5mm · Square 1/4in · Dot grid · Isometric ·
  Triangular · Hexagonal · Cornell notes · College ruled

TO PRINT: open the PDF for your paper size and print the page(s)
you need at 100% / 'Actual size' (do NOT 'fit to page', or the
grid spacing will scale). Black & white is fine.

For personal & classroom use. Print as many copies as you like.
Please don't resell or redistribute the files themselves.
(c) MathRelaxing · mathrelaxing.store
