Linear Algebra Formula Sheet
Vectors · Matrices · Eigenvalues  ·  Reference Plate
PLATE LA-01

INCLUDED
  prints/  — JPG masters @ 300 dpi (letter, A4, 2:3, 3:4, 4:5)

PRINTING
  · Letter / A4 for desk reference
  · Larger ratios for wall / classroom
  · Matte paper recommended

Personal study use. Not for redistribution or resale.
