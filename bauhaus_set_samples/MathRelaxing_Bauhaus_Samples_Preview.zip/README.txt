MathRelaxing Bauhaus Sample Set v2 — LETHAL (PREVIEW ONLY)
==========================================================

6 geometric compositions — tighter modular systems, stronger hierarchy,
paper grain, registration marks, gallery mockups.

Full Etsy product would include:
  · multi-ratio files (2:3, 3:4, 4:5, A4/A3)
  · 300 dpi print resolution
  · listing mockups + download ZIP

Palette: navy, cream, gold + Bauhaus red/blue.
