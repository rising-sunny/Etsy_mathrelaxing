COMPUTED ORGANIC - Abstract Wall Art Set of 6
MathRelaxing

Six abstract prints whose every shape is a plotted curve, not a drawing.

Each outline is either a truncated Fourier series in polar coordinates -- the
amplitudes fall off with harmonic number, so the curve is band-limited and
smooth by construction -- or Gielis' superformula, the equation that yields
petals, shells and rounded polygons from four exponents. The dot textures are
real lattices clipped to the outlines, not overlays.

01 Reef     midnight blue     02 Terrace  bone and terracotta
03 Canopy   deep forest       04 Neon     black and electric
05 Kiln     warm clay         06 Dusk     plum and peach

WHAT'S INCLUDED
  Each design at 9 x 11.5 in and 11 x 14 in, 300 dpi JPG.
  Both fit standard frames; print at home, at a copy shop or online.

This is a DIGITAL download - nothing is shipped.
(c) MathRelaxing. Personal use only. Not for redistribution or resale.
