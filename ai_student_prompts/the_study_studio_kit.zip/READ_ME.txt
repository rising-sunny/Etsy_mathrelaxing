The Study Studio — A Student'S Ai Toolkit

INCLUDED
  The_Study_Studio_Student_Prompts.pdf  — printable catalog of all prompts
  Study_Studio_interactive_tool.html  — open in any browser; pick a prompt, fill the blanks, click Copy. Works offline.

HOW TO USE
  Replace every [bracket] with your details, then paste into ChatGPT, Claude or Gemini.
  These help you understand and practise — not do the work for you. Always review before you rely on it or turn it in.

Original, curated prompts. Personal use. Not for redistribution or resale.
