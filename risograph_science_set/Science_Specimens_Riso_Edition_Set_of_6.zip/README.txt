Science Specimens: Riso Edition -- Set of 6
MathRelaxing scientific plate set

Six phenomena from math and physics -- cymatics, the golden spiral,
the five Platonic solids, the Bohr atom, a Koch snowflake, and two-slit
interference -- styled as naturalist specimen cards run through a two-colour
riso press: crisp black keyline, one halftone spot colour per plate, a
touch of registration offset, uncoated paper grain. Every pattern (the
Chladni nodal lines, the interference fringes, the logarithmic spiral) is
computed from the real underlying physics and mathematics, not decorative.

WHAT YOU GET
Six designs, each as a high-resolution JPG at 300 dpi, portrait ratio:
  - 9 x 11.5 in (signature size)
  - 11 x 14 in

Print at home, a print shop, or online lab. Simple black or natural-wood
frame recommended. Frame not included. Personal use only.

(c) MathRelaxing
