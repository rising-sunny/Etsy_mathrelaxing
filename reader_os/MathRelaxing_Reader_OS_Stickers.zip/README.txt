MathRelaxing — Reader OS Digital Sticker System
================================================

A functional sticker system for DIGITAL readers.

Made for:
  · iPad + GoodNotes / Notability / Freeform
  · Procreate reading journals
  · Kindle app screenshots & digital logs
  · Optional: print the master sheet on sticker paper

This is NOT a random cute pack.
Modules work as a reading "OS":

  STATUS      Currently Reading, TBR, DNF, Finished...
  PROGRESS    10%–100% rings, Last Chapter, Cliffhanger
  RATING      1–5 stars + Life Changing
  GENRE       Fantasy, Romance, Thriller, Sci-Fi...
  ANNOTATION  Plot Twist, Highlight, Bookmark, Trope Unlocked...
  MOOD        Cozy, Spicy, Dark Academia, Mind Blown...
  + chips (iPad session, GoodNotes log, e-reader night...) & mini book icons

CONTENTS
  stickers/png/           61 transparent PNGs (900×900)
  stickers/by_module/     same files sorted by module
  sheets/                 master sheet (optional print)
  README.txt

HOW TO USE ON IPAD
  1. Open the ZIP in the Files app and unzip
  2. GoodNotes: Insert image → save as Element for reuse
  3. Notability: Add photo → resize and duplicate
  4. Procreate: Import PNG as a stamp layer
  5. Stack STATUS + GENRE + RATING on each book entry

Personal use only. Not for resale of the sticker files.
© MathRelaxing
