MathRelaxing — William Morris–Inspired Botanical Print Set (v2 lethal)
6 original dense Arts & Crafts posters @ 300 dpi.
Sizes included: 24x36, 18x24, 16x20, 12x18, A4.
Scale 24x36 down for other frames. Matte paper recommended.
Personal use only. © MathRelaxing
