MathRelaxing — Bauhaus Geometric Print Set
==========================================

6 original geometric wall-art posters inspired by Bauhaus form, color, and balance.
Built for LARGE poster printing at true 300 dpi (print-shop ready).

PRINTS (folders)
  01_circles_bars
  02_triangles
  03_grid_modules
  04_arcs
  05_form_type
  06_balance

LARGE POSTER SIZES (print shop / oversized frames) — 300 dpi
  2x3_24x36  →  24×36 in   (7200×10800 px)
  3x4_18x24  →  18×24 in
  4x5_24x30  →  24×30 in
  5x7_20x28  →  20×28 in
  A1         →  594×841 mm
  A2         →  420×594 mm

STANDARD / HOME PRINTER — 300 dpi
  2x3_12x18  →  12×18 in
  3x4_12x16  →  12×16 in
  4x5_16x20  →  16×20 in
  5x7_10x14  →  10×14 in
  A3 / A4

You can scale a large file DOWN for smaller frames (never upscale a small file).

PRINT TIPS
  • Matte or lightly textured paper looks best
  • For 24×36 / A1: use a print shop (not most home printers)
  • Colors: navy, cream, gold, Bauhaus red & blue
  • Files are high-quality JPG, 300 dpi, chroma-sharp

Personal use only. Not for resale or redistribution.
© MathRelaxing
