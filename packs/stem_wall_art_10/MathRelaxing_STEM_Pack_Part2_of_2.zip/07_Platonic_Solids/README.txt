The Five Platonic Solids — Math Wall Art
MathRelaxing scientific plate (dark observatory edition)

Wireframe + shaded portraits of the five convex regular polyhedra:
  Tetrahedron · Cube · Octahedron · Dodecahedron · Icosahedron

Generated from exact coordinates (golden-ratio icosa/dodeca family).
Euler V−E+F=2 and Schläfli symbols {p,q} on the plate.

WHAT YOU GET
High-resolution JPG prints at 300 dpi:
  • 2:3  (12×18 in)
  • 3:4  (12×16 in)
  • 4:5  (16×20 in)
  • 5:7  (10×14 in)
  • ISO A4 and A3

Best on matte or semi-gloss paper. Frame not included. Personal use only.

© MathRelaxing
