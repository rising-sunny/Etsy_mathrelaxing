MathRelaxing — STEM Wall Art Pack (10 designs)
================================================
Thank you for purchasing this digital pack.

CONTENTS (10 folders):
1. Famous Equations — set of 6 scientific plates
2. Unit Circle — trigonometry reference poster
3. Ulam Spiral — prime numbers art print
4. Euler's Identity — complex plane art print
5. Black Hole Anatomy — Schwarzschild physics print
6. Schrödinger Equation — quantum mechanics print
7. Platonic Solids — sacred geometry poster
8. Special Functions — set of 6 scientific plates
9. Harmonic Series / Vibrating String
10. Fourier Series

Each folder contains high-resolution print-ready files (JPG/PDF as included).
Personal use only. Not for redistribution or resale of the digital files.
Shop: https://www.etsy.com/shop/TheMathRelaxing
