Special Functions — Wall Art Set of 6
MathRelaxing scientific plates

Six gallery prints in one download:
  1. Bessel Functions — circular drum modes Jn
  2. Hermite / Quantum Harmonic Oscillator — Hn wavefunctions
  3. Legendre Polynomials — multipoles on [-1,1]
  4. Laguerre Polynomials — half-line orthogonal basis
  5. Chebyshev Polynomials — minimax / equioscillation
  6. Airy Functions — turning points Ai & Bi

Each design includes 2:3 (12×18) and A4 masters at 300 dpi.
Matte paper recommended. Personal use only.

© MathRelaxing
