MathRelaxing — Physics Wall Art Pack (10 designs)
===================================================
Thank you for purchasing this digital pack.

CONTENTS (10 folders):
1. Maxwell Electromagnetism
2. Schrödinger Equation — quantum mechanics
3. Black Hole Anatomy — Schwarzschild physics
4. Wave Equation
5. Dirac Equation
6. Navier–Stokes equations
7. Fourier Series
8. Harmonic Series / Vibrating String
9. Special Functions — set of 6 scientific plates
10. Hermite polynomials / Quantum Harmonic Oscillator

Each folder contains high-resolution print-ready files (JPG/PDF as included).
Personal use only. Not for redistribution or resale of the digital files.
Shop: https://www.etsy.com/shop/TheMathRelaxing
